package com.example.university.service;

import com.example.university.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author university
 * @since 2024-05-29
 */
public interface MenuService extends IService<Menu> {

}
