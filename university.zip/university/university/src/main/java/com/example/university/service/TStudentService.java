package com.example.university.service;

import com.example.university.entity.TStudent;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author university
 * @since 2024-05-23
 */
public interface TStudentService extends IService<TStudent> {

}
