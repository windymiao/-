package com.example.university.entity;

import lombok.Data;

@Data
public class ScheduleRes extends Schedule{
    private String title;
    private String clazzName;
}
